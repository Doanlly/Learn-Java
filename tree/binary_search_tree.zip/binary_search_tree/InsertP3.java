package binary_search_tree;

import java.util.Scanner;

class Node {
    int data;
    Node left, right;

    public Node(int d) {
        data = d;
        left = right = null;
    }
}

class InsertP3 {
    // Function to insert a node in a BST.
    Node insert(Node root, int Key) {
        if (root == null)
            return new Node(Key);

        if (root.data < Key) {
            root.right = insert(root.right, Key);
        } else {
            root.left = insert(root.left, Key);
        }

        return root;
    }

    // Function to traverse a BST in inorder.
    void inorder(Node root) {
        if (root == null)
            return;

        inorder(root.left);
        System.out.print(root.data + " ");
        inorder(root.right);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Create an empty BST
        Node root = null;

        // Enter the number of nodes in the BST
        int n = sc.nextInt();

        // Insert the nodes into the BST
        InsertP3 solution = new InsertP3();
        for (int i = 0; i < n; i++) {
            int key = sc.nextInt();
            root = solution.insert(root, key);
        }

        // Traverse the BST in inorder
        solution.inorder(root);
    }
}
